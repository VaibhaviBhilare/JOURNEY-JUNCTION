import os
from django.conf import settings
from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required  # Ensure this is imported for the profile view
from trains.forms import TrainAdminCreationForm  # Correct import

def register_train_admin(request):
    # Print the directories Django is searching for templates
    print("Django template directories:")
    for directory in settings.TEMPLATES[0]['DIRS']:
        print(directory)



def home(request):
    print(f"Template directories: {settings.TEMPLATES[0]['DIRS']}")
    return render(request, 'home.html')


@login_required
def profile(request):
    return render(request, 'registration/profile.html')

def register_train_admin(request):
    if request.method == 'POST':
        form = TrainAdminCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            user.is_train_admin = True
            user.save()
            login(request, user)
            return redirect('home')
    else:
        form = TrainAdminCreationForm()
    return render(request, 'registration/register_train_admin.html', {'form': form})
from django.shortcuts import render

def register_train_admin(request):
    # Ensure 'registration/register_train_admin.html' matches your template path
    return render(request, 'registration/register_train_admin.html')
