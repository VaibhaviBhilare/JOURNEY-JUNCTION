from django.contrib import admin
from django.urls import path, include
from . import views
from django.contrib.auth import views as auth_views
from django.urls import path
urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),
    path('trains/', include('trains.urls')),
    path('register_train_admin/', views.register_train_admin, name='register_train_admin'),
    path('', views.home, name='home'),
    path('profile/', views.profile, name='profile'),
     path('accounts/login/', auth_views.LoginView.as_view(template_name='custom_login.html'), name='login'),
]
