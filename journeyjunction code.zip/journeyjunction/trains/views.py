from django.shortcuts import render, get_object_or_404, redirect
from .models import Train, Passenger, Department
from .forms import TrainForm, PassengerForm, DepartmentForm

def train_list(request):
    trains = Train.objects.all()
    return render(request, 'trains/train_list.html', {'trains': trains})

def add_train(request):
    if request.method == 'POST':
        form = TrainForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('train_list')
    else:
        form = TrainForm()
    return render(request, 'trains/add_train.html', {'form': form})

def edit_train(request, train_id):
    train = get_object_or_404(Train, id=train_id)
    if request.method == 'POST':
        form = TrainForm(request.POST, instance=train)
        if form.is_valid():
            form.save()
            return redirect('train_list')
    else:
        form = TrainForm(instance=train)
    return render(request, 'trains/edit_train.html', {'form': form})

def delete_train(request, train_id):
    train = get_object_or_404(Train, id=train_id)
    train.delete()
    return redirect('train_list')

def department_list(request):
    departments = Department.objects.all()
    return render(request, 'trains/department_list.html', {'departments': departments})

def add_department(request):
    if request.method == 'POST':  # Corrected this line by removing the extra parenthesis
        form = DepartmentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('department_list')
    else:
        form = DepartmentForm()
    return render(request, 'trains/add_department.html', {'form': form})

def edit_department(request, department_id):
    department = get_object_or_404(Department, id=department_id)
    if request.method == 'POST':
        form = DepartmentForm(request.POST, instance=department)
        if form.is_valid():
            form.save()
            return redirect('department_list')
    else:
        form = DepartmentForm(instance=department)
    return render(request, 'trains/edit_department.html', {'form': form})

def delete_department(request, department_id):
    department = get_object_or_404(Department, id=department_id)
    department.delete()
    return redirect('department_list')
