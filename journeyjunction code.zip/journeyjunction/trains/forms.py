from django import forms
from .models import Train, Passenger, Department
from django.contrib.auth.forms import UserCreationForm  # Import UserCreationForm
from .models import CustomUser

class TrainAdminCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = CustomUser
        fields = UserCreationForm.Meta.fields + ('is_train_admin',)

class TrainForm(forms.ModelForm):
    class Meta:
        model = Train
        fields = ['name', 'number', 'source', 'destination', 'departure_time', 'arrival_time', 'department']

class PassengerForm(forms.ModelForm):
    class Meta:
        model = Passenger
        fields = ['name', 'age', 'email', 'train']

class DepartmentForm(forms.ModelForm):
    class Meta:
        model = Department
        fields = ['name', 'description']

class TrainAdminCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = CustomUser
        fields = UserCreationForm.Meta.fields + ('is_train_admin',)