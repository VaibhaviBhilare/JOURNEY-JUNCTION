from django.urls import path
from . import views

urlpatterns = [
    path('', views.train_list, name='train_list'),
    path('add/', views.add_train, name='add_train'),
    path('<int:train_id>/edit/', views.edit_train, name='edit_train'),
    path('<int:train_id>/delete/', views.delete_train, name='delete_train'),
    path('departments/', views.department_list, name='department_list'),
    path('departments/add/', views.add_department, name='add_department'),
    path('departments/<int:department_id>/edit/', views.edit_department, name='edit_department'),
    path('departments/<int:department_id>/delete/', views.delete_department, name='delete_department'),
]
