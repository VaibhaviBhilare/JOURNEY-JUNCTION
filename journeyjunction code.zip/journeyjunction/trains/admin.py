from django.contrib import admin
from .models import Train, Passenger

admin.site.register(Train)
admin.site.register(Passenger)
